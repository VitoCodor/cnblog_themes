# 更新日志

## v2.0.3
* 整体优化左侧栏区域内容显示效果。
* 博文图片添加阴影效果，增加文字与图片的区别，提升布局效果 [#45](https://github.com/esofar/cnblogs-theme-silence/issues/43) 。
* 修复 CSS 伪元素`content`属性中文字符乱码问题 [#45](https://github.com/esofar/cnblogs-theme-silence/issues/45) 。

## v2.0.2
* 优化项目工程结构，包括去除全局工具依赖、封装构建命令等。
* 博文段落字号统一调整为`16px`，加粗字体权重调整为`500`。
* 博文详细页面移除博客标题动态显隐效果，避免引发界面交互上的一些其他问题。
* 修复博文标题出现链接导致生成的目录显示异常问题 [#26](https://github.com/esofar/cnblogs-theme-silence/issues/26)。
* 修复 TinyMCE 编辑器下的博文代码复制按钮点击异常跳转问题 [#31](https://github.com/esofar/cnblogs-theme-silence/issues/31)。

## v2.0.1
* 基于 [sponsor-page](https://github.com/Kaiyuan/sponsor-page/) 重构博文赞赏模块功能。
* 基于 [Lightbox2](https://lokeshdhakar.com/projects/lightbox2/) 新增博文图片灯箱功能。
* 移除自定义收藏按钮，其他部分元素细节调整。

## v2.0.0
* 支持多种主题风格。
* 新增博主信息模块功能。
* 若干页面样式细节调整。
* 优化代码结构，增加可读性。

## v1.1.3
* 新增右下角快捷操作工具栏。
* markdown 编辑模式下代码背景调整为亮色。

## v1.1.2
* 修复若干手机端适配问题。
* 调整标签列表页面显示效果。

## v1.1.1
* 修复代码复制按钮在非 markdown 编辑模式下位置错乱问题。
* 修复关注按钮被博客签名区域遮挡问题 [#6](https://github.com/esofar/cnblogs-theme-silence/issues/6) 。
* 优化关注按钮点击事件内部逻辑。
* 修复目录有序索引 title 显示异常问题。
* 修复手机端博文图片缩放问题。
* 优化博文标题显示效果。

## v1.1.0
* 调整博客图片为居中显示。
* 调整博客标题、段落上下间距。
* 调整非 markdown 编辑模式下代码风格。
* 新增代码复制按钮，该功能依赖 [clipboard.js](https://github.com/zenorocha/clipboard.js) 插件完成。
* 博客详情页面新增博主关注按钮 [#1](https://github.com/esofar/cnblogs-theme-silence/issues/1) 。

## v1.0.9
* 优化移动端浏览器存在的若干样式问题。
* 博客导航在移动端浏览器中显示标签页链接。
* 修复博文标题行内代码样式不统一的问题。
* 新增 [GitHub Corners](http://tholman.com/github-corners/)，通过`github`选项配置相关参数。

## v1.0.8
* 重新调整博文中Table表格样式。
* 调整博客目录最大宽高，优化笔记本小屏幕显示效果。
* 博客详情页面新增博客收藏按钮 [#2](https://github.com/esofar/cnblogs-theme-silence/issues/2) 。

## v1.0.7
* 版权信息输出主题版本号。
* 去除评论框outline效果。
* 博文字体大小调整为`15px`。
* 博文自定义摘要图片样式优化。

## v1.0.6
* 调整博客、博文标题左侧边距。
* 设置首页侧边栏、主体DOM元素默认最小高度。

## v1.0.5
* 调整全局字体样式。
* 调整博文引用样式。
* 调整博文行内代码样式。

## v1.0.4
* 优化阅读、正常模式切换效果。
* 修复移动端部分样式存在的问题。

## v1.0.3
* 更换全局字体。
* 优化标签列表页面部分样式。
* 优化侧边栏以及博客头部样式。

## v1.0.2
* 修复侧边栏我的标签、随笔分类因标题过长导致换行问题。
* 修复博客目录因标题过长导致换行问题。
* 优化评论区分页样式效果。
* 设置博客赞赏模块二维码固定宽高。
* 优化阅读模式、新增收缩标题栏效果。

## v1.0.1
* 赞赏按钮不显示时，适当调整其外层 DOM 元素宽度。
* 修复首页随笔分隔符样式不统一的问题。
